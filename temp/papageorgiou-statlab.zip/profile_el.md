\---

title: "Βασίλειος Παπαγεωργίου"

given\_name: "Βασίλειος"
last\_name: "Παπαγεωργίου"

sort\_name: "Παπαγεωργίου, Βασίλειος"

category: postdoc

position: Μεταδιδακτορικός Ερευνητής

office: ""

summary: Μεταδιδακτορικός ερευνητής στο Τμήμα Μαθηματικών του Εθνικού και Καποδιστριακού Πανεπιστημίου Αθηνών.

image: ""

email: "vpapageor@math.uoa.gr"

website: "https://www.researchgate.net/profile/Vasileios-Papageorgiou-3"

scholar: "https://scholar.google.com/citations?user=TvY44voAAAAJ\&hl=el"

orcid: "https://orcid.org/0000-0002-8131-3484"

github: ""

linkedin: "https://www.linkedin.com/in/vasileios-e-papageorgiou/"

interests:

* Στατιστική
* Στοχαστική Μοντελοποίηση
* Επιχειρησιακή Έρευνα
* Μηχανική Μάθηση

\---

